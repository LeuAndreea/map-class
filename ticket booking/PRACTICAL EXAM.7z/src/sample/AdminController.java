package sample;

import Domain.Booking;
import Repository.Repo;
import Service.Service;
import javafx.beans.InvalidationListener;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.*;

@SuppressWarnings( "deprecation" )
public class AdminController  implements Observer {
    private Service service;

    public AdminController(Service service) {
        this.service =service;
    }

    public AdminController(AdminController ctrl){
        this.service=ctrl.getService();
    }

    public void initialize(){

        this.refreshBookingList();
    }

    private void refreshBookingList() {


        ArrayList<Booking> bookings=new ArrayList<>(this.getService().getBookings().getObjects());
        ObservableList<Booking> obs = FXCollections.observableArrayList(bookings);

        this.bookingsView.getItems().clear();
        this.bookingsView.setItems(obs);
    }

    public Service getService() {
        return service;
    }



    @FXML
    protected ListView<Booking> bookingsView;

    @Override
    public void update(Observable o, Object arg) {
        this.refreshBookingList();

    }




}
