package sample;

import Domain.BMI;
import Domain.BP;
import Domain.MedicalAnalysis;
import Repo.Repo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;

import java.util.ArrayList;
import java.util.Calendar;

public class Controller {
    Repo analysis;

    @FXML
    private GridPane bmiMenu;

    @FXML
    private TextField bmiValue;

    @FXML
    private ListView<MedicalAnalysis> analysisView;

    @FXML
    private TextField dateTextBox;

    @FXML
    private ChoiceBox<String> typeChoiceBox;

    @FXML
    private GridPane bpMenu;

    @FXML
    private TextField systolicValue;

    @FXML
    private TextField diastolicValue;

    @FXML
    private Button continueButton;

    @FXML
    private Button addButton;

    @FXML
    private Button healthButton;

    @FXML
    private TextField healthyTextBox;


    public Controller(Repo analysis) {
        this.analysis = analysis;
    }

    @FXML
    void showMenu(ActionEvent event) {
        if (this.typeChoiceBox.getValue()==null){
            Alert a= new Alert(Alert.AlertType.WARNING);
            a.setContentText("You selected nothing!");
            a.show();
        }
        else {
            this.addButton.setVisible(true);

            if (this.typeChoiceBox.getValue() == "BMI") {
                this.bmiMenu.setVisible(true);
            } else
                this.bpMenu.setVisible(true);
        }
    }

    @FXML
    void addNewAnalysis(ActionEvent event) {
        String date= this.dateTextBox.getText();


        if (this.typeChoiceBox.getValue()=="BMI"){
            double value= Double.parseDouble(this.bmiValue.getText());
            BMI b=new BMI(date,value);

            this.analysis.addObject(b);

            this.bmiMenu.setVisible(false);

        }
        else{
                int systolicValue= Integer.parseInt(this.systolicValue.getText());
                int diastolicValue= Integer.parseInt(this.diastolicValue.getText());
                BP b=new BP(date,systolicValue,diastolicValue);

                this.analysis.addObject(b);

                this.bpMenu.setVisible(false);
        }

        this.addButton.setVisible(false);

        this.printList();
    }

    @FXML
    void isHealthy(ActionEvent event) {
        Calendar now = Calendar.getInstance();

        int month= now.get(Calendar.MONTH)+1;

        //boolean healthy= this.analysis.getObjects().stream().filter(a-> a.)
    }

    @FXML
    public void initialize() {


        System.out.println("FUCK.!");
        typeChoiceBox.getItems().add("BMI");
        typeChoiceBox.getItems().add("BP");

        this.printList();


    }

    @FXML
    public void printList(){
        ArrayList<MedicalAnalysis> analyses=new ArrayList<>(this.analysis.getObjects());
        ObservableList<MedicalAnalysis> obsAnalyses = FXCollections.observableArrayList(analyses);
        this.analysisView.setItems(obsAnalyses);
    }

}



