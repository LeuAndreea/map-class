package Domain;

public class MedicalAnalysis {
    protected String date;

    public MedicalAnalysis() { }

    public MedicalAnalysis(String date) {
        this.date = date;
    }

    public String getDate() {
        return date;
    }

    public boolean isResultOK(){return true; }

    @Override
    public String toString() {
        return "MedicalAnalysis{" +
                "date='" + date + '\'' +
                '}';
    }
}